﻿namespace Net.LawORM.Log.Error
{
    public enum SaveTypes : byte
    {
        File = 1,
        Database = 2,
        Cloud = 4
    };
}