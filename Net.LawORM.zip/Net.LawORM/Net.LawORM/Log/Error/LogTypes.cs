﻿namespace Net.LawORM.Log.Error
{
    public enum LogTypes
    {
        None = 0,
        Error = 1,
        Warn = 2,
        Info = 4,
        Debug = 8
    };
}
