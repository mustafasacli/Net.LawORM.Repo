﻿using Net.LawORM.Logic.BaseDal;
using System;

namespace Net.LawORM.Log.Transaction
{
    internal class TransactionLogDL : BaseDL
    {
        public TransactionLogDL()
            : base()
        { }

        public TransactionLogDL(String name)
            : base(name)
        { }
    }
}